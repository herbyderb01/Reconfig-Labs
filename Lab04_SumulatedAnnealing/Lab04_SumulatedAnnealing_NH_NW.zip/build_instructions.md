# Build Instructions

To build run:

```bash
g++ SimulatedAnnealing.cpp
```

and then run

```bash
./a.out input.txt output.txt
```
or
```bash
./a.out input2.txt output2.txt
```
or
```bash
./a.out input3.txt output3.txt
```